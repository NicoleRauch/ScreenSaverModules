
#define IDR_ICON		      10001
#define IDS_MODULENAME		1


#define IDT_ZORDERTIMER 	1000


#define IDD_CONFIGURE		3000

#define IDC_OK			   1
#define IDC_CANCEL		2
#define IDC_ENABLED		3001
#define IDC_DEFAULT		3010

#define IDC_GRAVITY	   3100
#define IDC_WHITESTARS 	3110
#define IDC_REDSTARS	   3120
#define IDC_BLUESTARS  	3130
#define IDC_YELLOWSTARS	3140
#define IDC_TRACENAME   3150
#define IDC_3D          3160

